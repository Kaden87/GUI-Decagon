package org.example.demo;

import javafx.application.Application;

import javafx.scene.Scene;



import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.shape.Polygon;




public class ShapeDemo extends Application {


    @Override
    public void start(Stage stage) throws Exception {
        Group root = new Group();

        stage.setTitle("Polygon Shape: Decagon");
        Polygon polygon = new Polygon();



        // Define the coordinates of the sides of the decagon
        Double[] sides = new Double[20]; // Each pair represents (x, y) coordinates of a vertex
        double centerX = 200; // Center X coordinate of the decagon
        double centerY = 200; // Center Y coordinate of the decagon
        double radius = 180; // Radius of the decagon, resizes the shape


        // Calculate the coordinates of the sides
        for (int i = 0; i < 10; i++) {
            double angle = Math.toRadians(36 * i);
            sides[2 * i] = centerX + radius * Math.cos(angle);
            sides[2 * i + 1] = centerY - radius * Math.sin(angle);
        }



        polygon.setFill(Color.BLUE);
        polygon.getPoints().addAll(sides); //To combine all the sides and to display the shape

        root.getChildren().add(polygon);
        Scene scene = new Scene(root, 400, 400);
        scene.setFill(Color.CORNSILK);


        stage.setScene(scene);
        stage.show();


    }


    public static void main (String[] args){
        launch(args);
        //test the code




    }



}
